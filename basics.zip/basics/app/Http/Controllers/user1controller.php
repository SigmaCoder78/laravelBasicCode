<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\users;

class user1controller extends Controller
{
    //
    function show1()
    {
        return users::all();

    }
}
