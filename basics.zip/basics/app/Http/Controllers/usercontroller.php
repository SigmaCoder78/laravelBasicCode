<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\users;

class usercontroller extends Controller
{
    
    function show()
    {
        return DB::select(" select * from users");

    }

  

}
