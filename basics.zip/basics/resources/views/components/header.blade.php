<div>
    <h1>HEADER COMPONENT</h1>
    <!-- Waste no more time arguing what a good man should be, be one. - Marcus Aurelius -->
</div>