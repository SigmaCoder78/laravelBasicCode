<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\usercontroller;
use App\Http\Controllers\user1controller;
use App\Http\Controllers\admincontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/adminform', function () {
    return view('Adminform');
});

Route::get('/userform', function () {
    return view('Userform');
});

Route::get("user",[usercontroller::class,'show']);
// Route::get("user",[user1controller::class,'show1']);
// Route::view("users","users");

Route::post("users",[admincontroller::class,'getdata']);

// Route::view("noaccess","noaccess");