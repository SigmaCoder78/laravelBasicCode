<div>
    <h1>HEADER COMPONENT</h1>
    <!-- Waste no more time arguing what a good man should be, be one. - Marcus Aurelius -->
</div><?php /**PATH C:\Users\MR\Documents\basics\resources\views/components/header.blade.php ENDPATH**/ ?>